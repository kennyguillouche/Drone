package com.example.kguillouche1.drone;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothClass;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.ParcelUuid;
import android.print.PrintAttributes;
import android.print.pdf.PrintedPdfDocument;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;


public class MainActivity extends AppCompatActivity {

    BluetoothAdapter mBluetoothAdapter;
    TextView capteur;
    TextView capteur2;
    TextView etat_connexion;
    TextView message_recue;

    TextView capteur3X;
    TextView capteur3Y;
    TextView capteur3Z;

    SeekBar seekBar;
    Spinner spinner;

    List<String> list = new ArrayList<String>();

    //Contient tous les appreils detectés
    BluetoothDevice[] ListeAppareil = new BluetoothDevice[20];

    //Recupert l'appreil choisi pour se connecter
    BluetoothDevice AppareilChosi;

    //Bluetooth echange
    BluetoothSocket socket;

    OutputStream mmOutputStream;
    InputStream mmInputStream;

    Thread ecoute;
    byte[] data;
    int position;
    private AtomicBoolean ThreadAlive = new AtomicBoolean();

    //Affichage des valeurs des capteurs
    private Handler myHandler = new Handler();;

    String message = "0:data";
    boolean affichage = false;

    int Progress_son = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button bouton_connection = (Button) findViewById(R.id.boutonConnexionDeconnection);
        final Button bouton_pdf = (Button) findViewById(R.id.button_save);

        //Creation des objets liés aux textview de l'interface
        capteur = (TextView) findViewById(R.id.Capteur);
        capteur2 = (TextView) findViewById(R.id.Capteur2);
        etat_connexion = (TextView) findViewById(R.id.etat_connexion);
        message_recue = (TextView) findViewById(R.id.message_recep);

        capteur3X = (TextView) findViewById(R.id.Capteur3X);
        capteur3Y = (TextView) findViewById(R.id.Capteur3Y);
        capteur3Z = (TextView) findViewById(R.id.Capteur3Z);

        seekBar = (SeekBar) findViewById(R.id.seekBar);
        seekBar.setClickable(false);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b)
            {
                seekBar.setProgress((int)Progress_son);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar)
            {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar)
            {

            }
        });
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            seekBar.setProgressTintList(ColorStateList.valueOf(Color.WHITE));
        }

        bouton_pdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {

            }
        });


        bouton_connection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                if (bouton_connection.getText().equals("CONNEXION") == true)
                {
                    OpenConnection();
                    bouton_connection.setText("DECONNEXION");
                }
                else if (bouton_connection.getText().equals("DECONNEXION") == true)
                {
                    Deconnection();
                    bouton_connection.setText("CONNEXION");
                }
            }
        });

        spinner = (Spinner) findViewById(R.id.ListeAppareilBluetooth);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                AppareilChosi = mBluetoothAdapter.getRemoteDevice(ListeAppareil[position].toString());
                etat_connexion.setText(String.valueOf(position));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });
        ActivationBluetooth();

    }
    private final static int REQUEST_CODE_ENABLE_BLUETOOTH = 0;

    void ActivationBluetooth()
    {
        int result_intent = 0;
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        //Verifie la presence du bluetooth sur l'appareil
        if(mBluetoothAdapter == null)
        {
            etat_connexion.setText("L'appareil ne possède pas de bluetooth");
            return;
        }

        //Verifie si le bluetooth est activé
        if(!mBluetoothAdapter.isEnabled())
        {
            Intent enableBluetooth = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBluetooth, REQUEST_CODE_ENABLE_BLUETOOTH);
        }

        //Si le bluetooth n'est toujours pas activé on sort
        if(!mBluetoothAdapter.isEnabled())
        {
            etat_connexion.setText("activer le bluetooth svp");
            return;
        }


        //Met l'appreil en visible pendant 300s
        Intent discoverableIntent =
                new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        discoverableIntent.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
        startActivity(discoverableIntent);


        //Recupere la liste des appareils visibles
        int i = 0;
        Set<BluetoothDevice> pairedDevices = mBluetoothAdapter.getBondedDevices();
        if(pairedDevices.size() > 0)
        {
            for(BluetoothDevice device : pairedDevices)
            {
                list.add(device.getName());
                ListeAppareil[i] = device;
                i++;
            }
        }
        //Ajoute la liste des appareils à notre liste déroulante
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);

        AppareilChosi = ListeAppareil[2];
    }

    void Deconnection()
    {
        //Si la connection est etablie on ferme la connection
        if(socket.isConnected())
        {
            try
            {
                mmInputStream.close();
                socket.close();
                etat_connexion.setText("Deconnection établie");
            } catch (IOException e)
            {
                e.printStackTrace();
            }
        }

        //on ferme le thread
        ThreadAlive.set(false);
        ecoute.interrupt();
        try
        {
            ecoute.join(100);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        //Supprime les message et data de la communication
        message = null;
        data = null;

        //Stop l'interruption timer
        myHandler.removeCallbacksAndMessages(null);
    }

    //interruption timer
    private Runnable UpdateValueSensor = new Runnable()
    {
        StringTokenizer tokens;
        String choix_capteur = "0";
        String data_capteur;
        int a = 0;

        public void run()
        {
            //trie les données de la data reçue

                try
                {

                    tokens = new StringTokenizer(message, ":");
                    choix_capteur = tokens.nextToken();
                    data_capteur = tokens.nextToken();

                    if(Integer.valueOf(data_capteur)>10000)
                    {
                        data_capteur = String.valueOf(Integer.valueOf(data_capteur)-65536);
                    }
                    if (Integer.valueOf(choix_capteur) >=0 && Integer.valueOf(choix_capteur) <5)
                    {
                        //affiche les données aux capteurs correspondants
                        switch (Integer.valueOf(choix_capteur)) {
                            case 0:
                                capteur.setText(data_capteur);
                                break;
                            case 1:
                                capteur2.setText(data_capteur);
                                break;
                            case 2:
                                capteur3X.setText(data_capteur);
                                break;
                            case 3:
                                capteur3Y.setText(data_capteur);
                                break;
                            case 4 :
                                 capteur3Z.setText(data_capteur);
                                 break;

                        }
                        tokens = null;

                    }
                }
                catch(Exception io)
                {

                }

            affichage = true;
            message_recue.setText(message);
            //lance l'interruption timer
            myHandler.postDelayed(this, 200);
        }
    };


    void OpenConnection()
    {
        ParcelUuid[] uuid = AppareilChosi.getUuids();
        Log.e("error",AppareilChosi.toString());
        try
        {
            socket = AppareilChosi.createRfcommSocketToServiceRecord(uuid[0].getUuid());

            //connecte l'echange de donne
            socket.connect();

            //Si on est connecté
            if(socket.isConnected())
            {
                //On initilise les lectures et ecriture de donnée bluetooth
                mmOutputStream = socket.getOutputStream();
                mmInputStream = socket.getInputStream();

                //Message etat
                etat_connexion.setText("Connection etablie");

                //initialise le Thread
                EcouteData();

                //Indique que le thread est actif via un boolean
                ThreadAlive.set(true);

                //Lance l'interruption timer d'affichage de donnée capteur => 500ms
                myHandler.postDelayed(UpdateValueSensor,200);
            }

        }
        catch (IOException e)
        {
            etat_connexion.setText("Connection erreur");
            e.printStackTrace();
        }

    }



    //Recupere les données
    void EcouteData()
    {
        data = new byte[1024];

        ecoute = new Thread(new Runnable()
        {
            int bytes;
            @Override
            public void run()
            {
                while (ThreadAlive.get() == true)
                {
                    try
                    {
                        //Regarde si on a reçu une trame
                        int bytesAvailable = mmInputStream.available();
                        if (bytesAvailable > 0 && affichage == true)
                        {
                            //on recupere la trame
                            bytes = mmInputStream.read(data);

                            //on recupere la data de la trame
                            message = new String(data,0,bytes);
                            affichage = false;
                        }
                    }
                    catch(IOException e)
                    {

                    }


                }
            }
        });
        //lance le thread
        ecoute.start();
    }

    protected void onDestroy()
    {
        super.onDestroy();
        ThreadAlive.set(false);
        ecoute.interrupt();
        try
        {
            ecoute.join(100);
        } catch (InterruptedException e)
        {
            e.printStackTrace();
        }
    }
}

