#include "mbed.h"
#include "ADXL345.h"

ADXL345_I2C accelerometer(PB_7,PB_6);
AnalogIn analog_value(PA_0);
AnalogIn analog_value1(PA_1);

Serial bluetooth(D1, D0,115200);

int main()
{
    float meas_r;
    float meas_v;
    float meas_r1;
    float meas_v1;
    char data[8];
    int lecture[3] = {0, 0, 0};
    
    //bit = 8 , pas de bit de parité, un bit de stop
    bluetooth.format(8,SerialBase::None,1);
     
    while(1) 
    { 
        accelerometer.getOutput(lecture);
        meas_r = analog_value.read(); // Read the analog input value (value from 0.0 to 1.0 = full ADC conversion range)
        meas_r1 = analog_value1.read();
        meas_v = meas_r * 3300; // Converts value in the 0V-3.3V range
        meas_v1 = meas_r1 * 2300; // Converts value in the 0V-3.3V range
        
        sprintf(data,"0:%.0f",meas_v);
        bluetooth.puts(data);
        //data=null;
        wait(0.20); // 50 msecond
        sprintf(data,"1:%.0f",meas_v1);
        bluetooth.puts(data);
        //data=null;
        wait(0.20); // 50 msecond
        
        sprintf(data,"2:%d",lecture[0]);
        bluetooth.puts(data);
        
        wait(0.20); // 50 msecond
        sprintf(data,"3:%d",lecture[1]);
        bluetooth.puts(data);
        
        wait(0.20); // 50 msecond
        sprintf(data,"4:%d",lecture[2]);
        bluetooth.puts(data);
        
        wait(0.20); // 50 msecond
    }
}